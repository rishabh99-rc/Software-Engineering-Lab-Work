/* --------------- Algorithm (201900307) -------------------------------

Step1: Start

Step2: Import all the required header files

Step3: Define a studet class which have all th3 student properties and datamembers
      and method studentinput to input the details of the student.And a statuschecker 
      to check the status of the fee payment and a studentoutput method to output the student
      registration details.


      
Step4: In the main funtion instansiate the object of Student class and call the studentinput method and 
      studentoutput method .

Step5: Stop.
*/

#include <iostream>
using namespace std;


class Student {
    private:
        long reg_no{};
        string password;
        string correct_password;
        long transaction_no{};
        float amount{};
        string date;
        int no_of_subs{};
        string sub_names[6];
        string sub_codes[6];
        int no_of_labs{};
        string lab_names[6];
        string lab_codes[6];
        int no_of_rejoins{};
        string rejoin_sub_names[6];
        string rejoin_sub_codes[6];
        int no_of_backlogs{};
        string backlogs_sub_names[6];
        string backlogs_sub_codes[6];


    public:
        Student() {	 	  	 	   	      	    	  	 	
            correct_password = "password123"; // SAMPLE PASSWORD, Use This Password For Testing

            cout << "Enter Student Details: " << endl;
            cout << "Registration Number: ";
            cin >> reg_no;
            cout << "Password: ";
            cin >> password;

            // Checking Password
            if(password == correct_password) {
                studentInput();
                studentOutput();
            }
            else{
                cout << "Incorrect Password";
            }
        }

        void studentInput() {
            cout << "Transaction Number: ";
            cin >> transaction_no;
            cout << "Transaction Amount: Rs. ";
            cin >> amount;
            cout << "Date of Transaction: ";
            cin >> date;

            cout << "Number of Regular Subjects: ";
            cin >> no_of_subs;
            if(no_of_subs != 0 ) {
                cout << "Enter Subject Codes & Names: "<< endl;
                for(int i = 0; i < no_of_subs; i++) {
                    cout <<"Subject Code " << i+1 << ": ";
                    cin >> sub_codes[i];
                    cout <<"Subject Name " << i+1 << ": ";
                    cin >> sub_names[i];
                }	 	  	 	   	      	    	  	 	
            }

            cout << "Number of Labs: ";
            cin >> no_of_labs;
            if(no_of_labs != 0 ) {
                cout << "Enter Lab Codes & Names: "<< endl;
                for(int i = 0; i < no_of_labs; i++) {
                    cout <<"Lab Code " << i+1 << ": ";
                    cin >> lab_codes[i];
                    cout <<"Lab Name " << i+1 << ": ";
                    cin >> lab_names[i];
                }
            }

            cout << "Number of Rejoin Subjects: ";
            cin >> no_of_rejoins;
            if(no_of_rejoins != 0 ) {
                cout << "Enter Rejoin Subject Codes & Names: "<< endl;
                for(int i = 0; i < no_of_rejoins; i++) {
                    cout <<"Subject Code " << i+1 << ": ";
                    cin >> rejoin_sub_codes[i];
                    cout <<"Subject Name " << i+1 << ": ";
                    cin >> rejoin_sub_names[i];
                }
            }

            cout << "Number of Back Papers: ";
            cin >> no_of_backlogs;
            if(no_of_backlogs != 0 ) {
                cout << "Enter Back Paper Subject Codes & Names: "<< endl;
                for(int i = 0; i < no_of_backlogs; i++) {
                    cout <<"Subject Code " << i+1 << ": ";
                    cin >> backlogs_sub_codes[i];
                    cout <<"Subject Name " << i+1 << ": ";
                    cin >> backlogs_sub_names[i];
                }	 	  	 	   	      	    	  	 	
            }
        }

        // Checks the registration status
        void statusChecker() const {
            if (amount == 150000) {
                cout << "Status: Registered" << endl;
            }
            else if (amount < 150000) {
                cout << "Status: Not Registered" << endl;
                cout << "Due Amount: Rs." << 150000 - amount << endl;
            }
            else {
                cout << "Status: Not Registered" << endl;
                cout << "Surplus Amount: Rs." << amount - 150000 << endl;
            }
        }

        void studentOutput() {
            cout << endl;
            cout << "Student Details: " << endl;
            cout << "Registration Number: " << reg_no << endl;
            cout << "Transaction Number: " << transaction_no << endl;
            cout << "Transaction Amount: Rs." << amount << endl;
            cout << "Date of Transaction: " << date << endl;

            if(no_of_subs != 0) {
                cout << "Regular Subjects: "<< endl;
                for(int i = 0 ; i < no_of_subs; i++) {
                    cout<< sub_codes[i] << " " << sub_names[i] << endl;
                }
            }

            if(no_of_labs != 0) {
                cout << "Labs: "<< endl;
                for(int i = 0 ; i < no_of_labs; i++) {	 	  	 	   	      	    	  	 	
                    cout<< lab_codes[i] << " " << lab_names[i] << endl;
                }
            }

            if(no_of_rejoins != 0) {
                cout << "Rejoined Subjects: "<< endl;
                for(int i = 0 ; i < no_of_rejoins; i++) {
                    cout<< rejoin_sub_codes[i] << " " << rejoin_sub_names[i] << endl;
                }
            }

            if(no_of_backlogs != 0) {
                cout << "Back Papers: "<< endl;
                for(int i = 0 ; i < no_of_backlogs; i++) {
                    cout<< backlogs_sub_codes[i] << " " << backlogs_sub_names[i] << endl;
                }
            }

            statusChecker();
        }
};

int main() {
    Student s1;
    return 0;
}	 	  	 	   	      	    	  	 	
