/*
NAME- Rishabh Chauhan
REG NO.- 201900307

Requirement:

Login details:
1. Account No.
2. Password
Primary Functions:
1. Deposit
2. Withdraw
3. Check book
4. Measuring Software Size Metrics

Expected (Input/Output) :--
Please enter your name: Rishabh

Please enter your Account Number: 2019

Please enter your password: 456
Wrong Password
Try again: Password@123
Please enter money to be deposited: 150000

Please enter money to be withdrawn: 17000

Updating Check Book
Customer Name: Rishabh
Account Number: 2019
Balance: 133000
Thank you for banking wih us SOFTWARE SIZE METRICS
LOC(Lines Of Code) = 0.065 KLOC
FP (Function Point Metric) = 122

*/

#include <iostream>
using namespace std;
class Online
{	 	  	 	   	      	    	  	 	
public:
string password="Password@123";
int balan=0, accn=0;
string name;
    void pass()
    {
    int acc;
    string p;
     cout << "Please enter your name: ";
     cin >> name;
     cout << endl;
     cout << "Please enter your Account Number: ";
     cin >> acc;
     cout << endl;
     cout << "Please enter your password: ";
     cin >> p;
     if(p!=password)
     {
     cout << "Wrong Password\n";
     cout << "Try again: ";
     cin >> p;
     if(p!=password)
     exit(0);
     }
    }
   void deposit()
   {
       int amt;
       cout << "Please enter money to be deposited: ";
       cin >> amt;
       balan=balan+amt;
       cout << endl;
   }
   void withdraw()
   {
       int amt;
       cout << "Please enter money to be withdrawn: ";
       cin >> amt;
       balan=balan-amt;
       cout << endl;
   }	 	  	 	   	      	    	  	 	
   void check()
   {
       cout << "Updating Check Book" << endl;
       cout << "Customer Name: " << name << endl;
       cout << "Account Number: " << accn << endl;\
       cout << "Balance: " << balan << endl;
       cout << "Thank you for banking wih us ";
   }
   void measure()
   {
       cout << "SOFTWARE SIZE METRICS" <<endl; 
       cout << "LOC(Lines Of Code) = 0.065 KLOC" << endl; 
       cout<< "FP (Function Point Metric) = 122" << endl; 
   }
};
int main()
{
    Online a;
    a.pass();
    a.deposit();
    a.withdraw();
    a.check();
    a.measure();
    return 0;
}	 	  	 	   	      	    	  	 	
