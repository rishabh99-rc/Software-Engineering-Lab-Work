/*
NAME- Rishabh Chauhan
REG NO.- 201900307

Requirement:

Login details:
1. Reg No.
2. Password

Transaction Details:
1. Transaction Number
2. Transaction Amount: Rs.
3. Date of Transaction:

Types Of Student:
1. Regular student with rejoin subject
2. Regular student with no rejoin subject

Subject Details:
1. Number of Subject
2. Subject Code
3. Subject Name

Testing:
1. Password Validity
2. Transaction Validity

Expected (Input/Output) :--
Enter Student Details:
Registration Number: 23
Password: password123
        STUDENT SEMESTER REGISTRATION

 1. Regular Student Without Rejoin Subjjects
 2. Regular Student With Rejoin Subjects
Enter your choice: 1
Transaction Number: 23
Transaction Amount: Rs. 15500
Date of Transaction: 28/12/2001
Number of Regular Subjects: 1
Enter Subject Codes & Names:
Subject Code 1: 23
Subject Name 1: OS
Number of Labs: 1
Enter Lab Codes & Names:
Lab Code 1: 23
Lab Name 1: OS
Number of Back Papers: 2
Enter Back Paper Subject Codes & Names:
Subject Code 1: 23
Subject Name 1: MAT
Subject Code 2: 2
Subject Name 2: ENG

Student Details:
Registration Number: 23
Transaction Number: 23
Transaction Amount: Rs.15500
Date of Transaction: 28/12/2001
Regular Subjects:
23 2
Labs:
23 3
Back Papers:
23 34
2 2
Status: Not Registered
Due Amount: Rs.134500
*/


#include <iostream>
using namespace std;


class Student {	 	  	 	   	      	    	  	 	
private:
    long reg_no;
    string password;
    string correct_password;
    long transaction_no;
    float amount;
    string date;
    int no_of_subs = 0;
    string sub_names[6];
    string sub_codes[6];
    int no_of_labs = 0;
    string lab_names[6];
    string lab_codes[6];
    int no_of_rejoins = 0;
    string rejoin_sub_names[6];
    string rejoin_sub_codes[6];
    int no_of_backlogs = 0;
    string backlogs_sub_names[6];
    string backlogs_sub_codes[6];
    int choice;

public:
    Student();
    void regular_without_rejoin_sub();
    void regular_with_rejoin_sub();
    void transaction_details();
    void regular_sub();
    void rejoin_sub();
    void labs();
    void back_papers();
    void statusChecker() const;
    void studentOutput();
};

Student::Student() {
    // Use This Password For Testing
    correct_password = "password123";

    cout << "Enter Student Details: " << endl;
    cout << "Registration Number: ";
    cin >> reg_no;
    cout << "Password: ";
    cin >> password;

    // Checking Password
    if (password == correct_password) {	 	  	 	   	      	    	  	 	
        cout << "\t\tSTUDENT SEMESTER REGISTRATION \n\n ";
        cout << "1. Regular Student Without Rejoin Subjjects\n ";
        cout << "2. Regular Student With Rejoin Subjects\n"   ;

        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            regular_without_rejoin_sub();
            break;

        case 2:
            regular_with_rejoin_sub();
            break;

        default:
            cout << "Incorrect Selection";
        }

        studentOutput();
    }

    else {
        cout << "Incorrect Password";
    }
}

void Student::regular_without_rejoin_sub() {
    transaction_details();
    regular_sub();
    labs();
    back_papers();

}


void Student::regular_with_rejoin_sub() {	 	  	 	   	      	    	  	 	
    transaction_details();
    regular_sub();
    rejoin_sub();
    labs();
    back_papers();

}

void Student::transaction_details() {
    cout << "Transaction Number: ";
    cin >> transaction_no;
    cout << "Transaction Amount: Rs. ";
    cin >> amount;
    cout << "Date of Transaction: ";
    cin >> date;

}


void Student::regular_sub() {
    cout << "Number of Regular Subjects: ";
    cin >> no_of_subs;
    if (no_of_subs != 0 ) {
        cout << "Enter Subject Codes & Names: " << endl;
        for (int i = 0; i < no_of_subs; i++) {
            cout << "Subject Code " << i + 1 << ": ";
            cin >> sub_codes[i];
            cout << "Subject Name " << i + 1 << ": ";
            cin >> sub_names[i];
        }
    }

}


void Student::rejoin_sub() {	 	  	 	   	      	    	  	 	
    cout << "Number of Rejoin Subjects: ";
    cin >> no_of_rejoins;
    if (no_of_rejoins != 0 ) {
        cout << "Enter Rejoin Subject Codes & Names: " << endl;
        for (int i = 0; i < no_of_rejoins; i++) {
            cout << "Subject Code " << i + 1 << ": ";
            cin >> rejoin_sub_codes[i];
            cout << "Subject Name " << i + 1 << ": ";
            cin >> rejoin_sub_names[i];
        }
    }

}


void Student::labs() {
    cout << "Number of Labs: ";
    cin >> no_of_labs;
    if (no_of_labs != 0 ) {
        cout << "Enter Lab Codes & Names: " << endl;
        for (int i = 0; i < no_of_labs; i++) {
            cout << "Lab Code " << i + 1 << ": ";
            cin >> lab_codes[i];
            cout << "Lab Name " << i + 1 << ": ";
            cin >> lab_names[i];
        }
    }

}


void Student::back_papers() {
    cout << "Number of Back Papers: ";
    cin >> no_of_backlogs;
    if (no_of_backlogs != 0 ) {
        cout << "Enter Back Paper Subject Codes & Names: " << endl;
        for (int i = 0; i < no_of_backlogs; i++) {	 	  	 	   	      	    	  	 	
            cout << "Subject Code " << i + 1 << ": ";
            cin >> backlogs_sub_codes[i];
            cout << "Subject Name " << i + 1 << ": ";
            cin >> backlogs_sub_names[i];
        }
    }

}

// Checks the registration status
void Student::statusChecker() const {
    if (amount == 150000) {
        cout << "Status: Registered" << endl;
    }
    else if (amount < 150000) {
        cout << "Status: Not Registered" << endl;
        cout << "Due Amount: Rs." << 150000 - amount << endl;
    }
    else {
        cout << "Status: Registered" << endl;
        cout << "Surplus Amount: Rs." << amount - 150000 << endl;
    }
}

void Student::studentOutput() {
    cout << endl;
    cout << "Student Details: " << endl;
    cout << "Registration Number: " << reg_no << endl;
    cout << "Transaction Number: " << transaction_no << endl;
    cout << "Transaction Amount: Rs." << amount << endl;
    cout << "Date of Transaction: " << date << endl;

    if (no_of_subs != 0) {
        cout << "Regular Subjects: " << endl;
        for (int i = 0 ; i < no_of_subs; i++) {
            cout << sub_codes[i] << " " << sub_names[i] << endl;
        }	 	  	 	   	      	    	  	 	
    }

    if (no_of_labs != 0) {
        cout << "Labs: " << endl;
        for (int i = 0 ; i < no_of_labs; i++) {
            cout << lab_codes[i] << " " << lab_names[i] << endl;
        }
    }

    if (no_of_rejoins != 0) {
        cout << "Rejoined Subjects: " << endl;
        for (int i = 0 ; i < no_of_rejoins; i++) {
            cout << rejoin_sub_codes[i] << " " << rejoin_sub_names[i] << endl;
        }
    }

    if (no_of_backlogs != 0) {
        cout << "Back Papers: " << endl;
        for (int i = 0 ; i < no_of_backlogs; i++) {
            cout << backlogs_sub_codes[i] << " " << backlogs_sub_names[i] << endl;
        }
    }

    statusChecker();
}


int main() {
    Student s1;
    return 0;
}	 	  	 	   	      	    	  	 	
