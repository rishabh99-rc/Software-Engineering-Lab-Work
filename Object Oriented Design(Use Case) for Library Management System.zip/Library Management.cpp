#include <bits/stdc++.h>
#include <cstdlib>
#include <string>

using namespace std;

class Bank
{
public:
    int transNumber, transac=0, ret=0;
    string name, password, pay, p, newname, newpass, search, borrow, feedback="No Feedback provided";
    string bn[5], rn[5];
    long long regnum, bal=10000, amt;
    void Reg()
    {
        cout << "\n";
        cout << "Your Profile" << endl;
        cout << "\n";
        cout << "Enter Name: ";
        cin >> newname;
        cout << "Enter Registration No: ";
        cin >> regnum;
        cout << "Enter password: ";
        cin >> newpass;
        string check;
        cout << "\n";
    }
    void Info()
    {
        cout << "LIBRARY" << endl;
        cout << "\n";
        cout << "Enter Name: ";
        cin >> name;
        cout << "Password: ";
        cin >> password;
        cout << "\n\n";
    }	 	  	 	   	      	    	  	 	
   void Dep()
   {
       cout << "\n";
       cout << "Search by Book Name: ";
       cin >> search;
       cout << "Available for borrowing";
   }
   void With()
   {
       cout << "\n";
       cout << "Enter book to be borrowed: ";
       cin >> bn[transac];
       transac++;
       cout << "\n";
       cout <<"Book Borrowed: ";
       cout << bn[transac-1] << "\n\n";
   }
   void Trans()
   {
       cout << "\n";
       cout << "Enter Book Name to be returned: ";
       cin >> rn[ret];
       ret++;
       cout <<"Book Returned: ";
       cout << rn[ret-1] << "\n\n";
   }
   void Display()
   {
        cout << "\n";
        cout << "Name: " << name <<"\n";
        cout << "Registration No: " << regnum <<"\n";
        cout << "Books borrowed\n";
        for(int i=0; i<transac; i++)
        {
            cout << bn[i] <<"\n";
        }	 	  	 	   	      	    	  	 	
        cout << "Books returned \n";
        for(int i=0; i<ret; i++)
        {
            cout << rn[i] <<"\n";
        }
   }
};
int main()
{
    Bank obj;
    char ch;
    obj.Reg();
    obj.Info();
    int a=1;
    while(a==1)
    {
    cout << "\n";
    cout << "Enter 1 for search \n";
    cout << "Enter 2 for borrowing \n";
    cout << "Enter 3 for returning \n";
    cout << "Enter your choice: ";
    cin >> ch;
    switch(ch)
    {
        case '1':
        obj.Dep();
        break;
        case '2':
        obj.With();
        break;
        case '3':
        obj.Trans();
        break;
    }
        cout << "\n\n";
        cout <<  "Do you wish to continue? Enter 1 to continue, 0 to exit: ";
        cin >> a;
        cout << "\n";
    }	 	  	 	   	      	    	  	 	
    obj.Display();
    return 0;
}